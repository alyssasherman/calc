import UIKit

//input values
var inputOne = 20
var inputTwo = 10

//operations
let addition = inputOne + inputTwo
let subtraction = inputOne - inputTwo
let divison = inputOne / inputTwo
let multiplication = inputOne * inputTwo

//prints
print ( "addition answer: \(addition) \n")
print ( "subtraction answer: \(subtraction) \n")
print ( "divison answer: \(divison) \n")
print ( "multiplication: \(multiplication) \n")



